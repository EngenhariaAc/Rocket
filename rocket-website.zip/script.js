function launchRocket() {
  const rocket = document.getElementById('rocket');
  rocket.style.transform = "translateY(-400px)";
}
